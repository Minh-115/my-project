var nutchon=document.getElementsByTagName('input'); //1 mang cac input
for(var i=0;i<nutchon.length;i++){
    nutchon[i].addEventListener('click',function(){
        var chano=this.parentElement;
        var anhem=chano.children;// lai la 1 mang
        alert(anhem[2].getAttribute('data-price'));
    });
}